#ifndef DIAS_H
#define DIAS_H
#include<math.h>
#include <iostream>
#include "Fecha.h"
using namespace std;


class Dias{
	private:
	Fecha f1;
	Fecha f2;

	public:
	Dias(){
		cout << " Detectamos algunos dias"<<endl;

	}
	void setF1(int a, int m, int d){
		f1.setAnio(a);
		f1.setMes(m);
		f1.setDia(d);

	}

	void setF2(int a, int m, int d){
		f2.setAnio(a);
		f2.setMes(m);
		f2.setDia(d);

	}

	void calculo(){
    int aniomayor,mesmayor,diamayor,aniomenor,mesmenor,diamenor;
	int contar=0;

	if (f1.getAnio() > f2.getAnio()){

		aniomayor=f1.getAnio();
		mesmayor=f1.getMes();
		diamayor=f1.getDia();
		aniomenor=f2.getAnio();
		mesmenor=f2.getMes();
		diamenor=f2.getDia();
	}


  for(int i=aniomenor; i<aniomayor;i++){
    if(i%4==0 and i%100!=0){
      contar=contar+1;
    }
  }

  int diasmayor,diasmenor,diasdiferencia;
  diasmayor=aniomayor*365 + mesmayor*30 + aniomayor;
  diasmenor=aniomenor*365 + mesmenor*30 + aniomenor;

   diasdiferencia=(diasmayor-diasmenor)+contar;

   cout<<"\n La Diferencia de dias es  :"<<diasdiferencia<<endl;
  }

	protected:
};

#endif // DIAS_H
