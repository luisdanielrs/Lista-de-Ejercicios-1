#ifndef FECHA_H
#define FECHA_H


class Fecha
{
	private:
		int anio;
		int mes;
		int dia;
	public:
	Fecha(int ani,int mesi, int dii);
    Fecha();
	void setAnio(int a);
	void setMes(int b);
	void setDia(int c);

	int getAnio()const;
	int getMes()const;
	int getDia()const;

	void print();

	protected:
};

#endif // FECHA_H
