#include <iostream>
#include <cmath>
#include "Fecha.h"
#include "Dias.h"
using namespace std;

int main(){
	Dias f1;
	int d,m,a;
	cout<<"Ingrese primer fecha (dia/mes/anio): "<<endl;
	 cin>>a>>m>>a;
	 f1.setF1(a,m,d);

	cout<<"Ingrese segunda fecha (dia/mes/anio): "<<endl;
	 cin>>a>>m>>a;
	 f1.setF2(a,m,d);

	f1.calculo();


}
