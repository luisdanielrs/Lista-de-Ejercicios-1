#include "Fecha.h"

#include <math.h>
#include <iostream>

using namespace std;

Fecha::Fecha(int a, int m, int d){
anio = a;
mes = m;
dia = d;
}
Fecha::Fecha(){}

void Fecha::setAnio(int a){
	anio = a;
}
void Fecha::setMes(int m){
	mes = m;
}
void Fecha::setDia(int d){
	dia=d;
}
int Fecha::getAnio()const{
	return anio;
}
int Fecha::getMes()const{
    return mes;
}
int Fecha::getDia()const{
    return dia;
}
void Fecha::print(){
	cout << "Fecha: "<<anio<<" /"<<mes<<" /"<<dia<<endl;
}
