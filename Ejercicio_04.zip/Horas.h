#ifndef HORAS_H
#define HORAS_H
#include "Tiempo.h"
using namespace std;
class Horas{
	private:
	Horas hr;
	Horas mi;

	public:
Horas(){
}

	void setH(float h, float m, float s){
	hr.setH(h);
	hr.setM(m);
	hr.setS(s);


	}
	void setH2(float h, float m, float s){
	mi.setH(h);
	mi.setM(m);
	mi.setS(s);


	}
	void print(){


	}
	float lahora(){
	;
	float hrr =   (60 * hr.getH()) + (60 / hr.getM());
	float hrr1 =  (60 * mi.getH()) + (60 / mi.getM());
	return (hrr1-hrr);
	}
	protected:
};

#endif
