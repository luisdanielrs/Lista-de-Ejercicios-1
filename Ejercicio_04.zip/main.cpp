#include <iostream>
#include "Horas.h"
#include "Tiempo.h"
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {

Horas hr;

float h,s,m;
cout <<"calculo aparir de 1:1:1"<<endl;
cout<< "ingrese h:m:s"<<endl;
cin >>h >> m>> s;
hr.setH(h,m,s);

float h1,s1,m1;

cout<< "ingrese2 h:m:s"<<endl;
cin >>h1 >> m1>> s1;
hr.setH2(h1,m1,s1);

cout << "dif de seg: "<< hr.lahora() <<endl;


}
