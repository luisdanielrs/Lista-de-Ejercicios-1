#include <iostream>
#include "Tiempo.h"
using std::cout;
using std::endl;

Tiempo::Tiempo(float h, float m, float s){
hr = h;
min = m;
seg = s;
}
Tiempo::Tiempo(){
}
void Tiempo::setH(float h){
hr= h;
}
float Tiempo::getH() {return hr;
}
void Tiempo::setM(float m){
	min = m;
}
float Tiempo::getM(){return min;

}
void Tiempo::setS(float s){
	seg = s;

}float Tiempo::getS(){
	return seg;
}
void Tiempo::print(){
	cout << " la hora es: "<< hr <<" :"<< min <<" :"<< seg <<endl;
}
