#ifndef TIEMPO_H
#define TIEMPO_H



class Tiempo
{


	private:
		float min;
		float hr;
		float seg;
	public:
	Tiempo(float h,float m,float s);
	Tiempo();

	void setM(float min);
	float getM();

	void setH(float hor);
	float getH();

	void setS(float seg);
	float getS();

	void print();
	protected:
};

#endif // _H
